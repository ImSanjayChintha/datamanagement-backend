"""
Gateway endpoint admin CRUD.

All routes are POST (admin convention) and require a valid admin JWT.
"""
import json
import logging

import asyncpg
from fastapi import APIRouter, Body, Depends

from app.core.database import get_db
from app.core.deps import get_current_admin
from app.core.response import ok, err
from app.modules.api_bridge.gateway.db.setup import create_schema_translations
from app.modules.api_bridge.engine.registry import registry as _engine_registry

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/gateway/endpoints", tags=["Gateway"])

VALID_METHODS  = {"GET", "POST", "PUT", "PATCH", "DELETE"}
VALID_DB_TYPES = {"table", "view", "function", "service"}
VALID_STATUSES = {"draft", "active", "deprecated"}
VALID_OP_TYPES = {"select", "insert", "update", "delete"}


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

async def _auto_register(
    db: asyncpg.Connection,
    schema: str | None,
    obj: str | None,
    url_path: str | None = None,
) -> None:
    """Ensure schema.obj is in toolkit.api_objects so the engine executor has field metadata.

    The gateway URL is resolved via api_gateway.endpoints (not slug lookup),
    so no slug manipulation is needed here.
    """
    if not schema or not obj:
        return
    try:
        await db.execute("SELECT toolkit.fn_register_table($1, $2)", schema, obj)
        await _engine_registry.invalidate(f"{schema}.{obj}")
    except Exception as exc:
        logger.warning("auto_register %s.%s failed: %s", schema, obj, exc)


def _row(r) -> dict:
    """Convert an asyncpg Row to a serialisable dict."""
    d = dict(r)
    for key in ("headers", "body_schema", "filters", "columns", "config"):
        if key in d and not isinstance(d[key], (list, dict)):
            d[key] = json.loads(d[key]) if d[key] else ({} if key in ("body_schema", "config") else [])
    if d.get("inserted_at"):
        d["inserted_at"] = d["inserted_at"].isoformat()
    if d.get("modified_at"):
        d["modified_at"] = d["modified_at"].isoformat()
    # Expose settings stored inside config as top-level fields
    cfg = d.get("config") or {}
    d["pagination_enabled"] = cfg.get("pagination_enabled", True)
    d["default_limit"]      = cfg.get("default_limit", 20)
    d["max_limit"]          = cfg.get("max_limit", 100)
    d["include_total"]      = cfg.get("include_total", False)
    d["count_limit"]        = cfg.get("count_limit", 10_000)
    d["response_extras"]    = cfg.get("response_extras", [])
    d["response_key"]       = cfg.get("response_key", "rows")
    d["resource_code"]      = cfg.get("resource_code") or None
    return d


def _validate_common(body: dict) -> tuple:
    """Validate common fields. Returns (name, url_path, method, db_type, op_type)."""
    name     = (body.get("name") or "").strip()
    url_path = (body.get("url_path") or "").strip()
    method   = (body.get("method") or "GET").upper()

    if not name:
        raise ValueError("name is required")
    if not url_path:
        raise ValueError("url_path is required")
    if method not in VALID_METHODS:
        raise ValueError(f"method must be one of {sorted(VALID_METHODS)}")

    db_type = body.get("db_type") or None
    if db_type and db_type not in VALID_DB_TYPES:
        raise ValueError(f"db_type must be one of {sorted(VALID_DB_TYPES)}")

    op_type = body.get("operation_type") or None
    if op_type and op_type not in VALID_OP_TYPES:
        raise ValueError(f"operation_type must be one of {sorted(VALID_OP_TYPES)}")

    return name, url_path, method, db_type, op_type


# ---------------------------------------------------------------------------
# List / Get
# ---------------------------------------------------------------------------

@router.post("/list")
async def list_endpoints(
    body:  dict = Body(default={}),
    db:    asyncpg.Connection = Depends(get_db),
    admin: dict = Depends(get_current_admin),
):
    search    = (body.get("search")   or "").strip()
    status_f  = (body.get("status")   or "").strip()
    page      = max(1, int(body.get("page")      or 1))
    page_size = max(1, min(100, int(body.get("page_size") or 25)))
    offset    = (page - 1) * page_size

    try:
        filters, args = [], []

        if search:
            args.append(f"%{search}%")
            p = len(args)
            filters.append(
                f"(name ILIKE ${p} OR url_path ILIKE ${p}"
                f" OR COALESCE(db_schema,'') ILIKE ${p}"
                f" OR COALESCE(db_object,'') ILIKE ${p})"
            )
        if status_f and status_f in VALID_STATUSES:
            args.append(status_f)
            filters.append(f"status = ${len(args)}")

        where = ("WHERE " + " AND ".join(filters)) if filters else ""

        total = await db.fetchval(
            f"SELECT COUNT(*) FROM api_gateway.endpoints {where}", *args
        )
        rows = await db.fetch(
            f"SELECT * FROM api_gateway.endpoints {where}"
            f" ORDER BY inserted_at DESC"
            f" LIMIT ${len(args) + 1} OFFSET ${len(args) + 2}",
            *args, page_size, offset,
        )
        pages = max(1, (total + page_size - 1) // page_size)
        return ok({
            "rows":      [_row(r) for r in rows],
            "total":     total,
            "page":      page,
            "page_size": page_size,
            "pages":     pages,
        })
    except Exception as exc:
        logger.error("list_endpoints: %s", exc)
        return err(str(exc))


@router.post("/get")
async def get_endpoint(
    body:  dict = Body(default={}),
    db:    asyncpg.Connection = Depends(get_db),
    admin: dict = Depends(get_current_admin),
):
    eid = body.get("id")
    if not eid:
        return err("id required")
    try:
        row = await db.fetchrow(
            "SELECT * FROM api_gateway.endpoints WHERE id=$1", int(eid)
        )
        return ok(_row(row)) if row else err("Not found")
    except Exception as exc:
        logger.error("get_endpoint %s: %s", eid, exc)
        return err(str(exc))


# ---------------------------------------------------------------------------
# Create
# ---------------------------------------------------------------------------

@router.post("/create")
async def create_endpoint(
    body:  dict = Body(default={}),
    db:    asyncpg.Connection = Depends(get_db),
    admin: dict = Depends(get_current_admin),
):
    try:
        name, url_path, method, db_type, op_type = _validate_common(body)
    except ValueError as exc:
        return err(str(exc))

    try:
        db_schema = body.get("db_schema") or None
        db_object = body.get("db_object") or None
        config = body.get("config") or {}
        config["pagination_enabled"] = body.get("pagination_enabled", True)
        config["default_limit"]      = body.get("default_limit", 20)
        config["max_limit"]          = body.get("max_limit", 100)
        config["include_total"]      = body.get("include_total", False)
        config["count_limit"]        = int(body.get("count_limit") or 10_000)
        config["response_extras"]    = body.get("response_extras") or []
        config["response_key"]       = (body.get("response_key") or "rows").strip() or "rows"
        config["resource_code"]      = body.get("resource_code") or None
        if body.get("service_response") is not None:
            config["service_response"] = body["service_response"]
        row = await db.fetchrow(
            """INSERT INTO api_gateway.endpoints
               (name, url_path, method, db_schema, db_object, db_type,
                headers, body_schema, filters, columns, description, status,
                operation_type, config)
               VALUES ($1,$2,$3,$4,$5,$6,
                       $7::jsonb,$8::jsonb,$9::jsonb,$10::jsonb,
                       $11,$12,$13,$14::jsonb)
               RETURNING *""",
            name, url_path, method,
            db_schema, db_object, db_type,
            json.dumps(body.get("headers")     or []),
            json.dumps(body.get("body_schema") or {}),
            json.dumps(body.get("filters")     or []),
            json.dumps(body.get("columns")     or []),
            body.get("description") or None,
            body.get("status") or "draft",
            op_type,
            json.dumps(config),
        )
        if db_type != "service":
            await _auto_register(db, db_schema, db_object, url_path)
        return ok(_row(row))
    except Exception as exc:
        logger.error("create_endpoint: %s", exc)
        return err(str(exc))


# ---------------------------------------------------------------------------
# Update
# ---------------------------------------------------------------------------

@router.post("/update")
async def update_endpoint(
    body:  dict = Body(default={}),
    db:    asyncpg.Connection = Depends(get_db),
    admin: dict = Depends(get_current_admin),
):
    eid = body.get("id")
    if not eid:
        return err("id required")

    try:
        name, url_path, method, db_type, op_type = _validate_common(body)
    except ValueError as exc:
        return err(str(exc))

    try:
        db_schema = body.get("db_schema") or None
        db_object = body.get("db_object") or None
        config = body.get("config") or {}
        config["pagination_enabled"] = body.get("pagination_enabled", True)
        config["default_limit"]      = body.get("default_limit", 20)
        config["max_limit"]          = body.get("max_limit", 100)
        config["include_total"]      = body.get("include_total", False)
        config["count_limit"]        = int(body.get("count_limit") or 10_000)
        config["response_extras"]    = body.get("response_extras") or []
        config["response_key"]       = (body.get("response_key") or "rows").strip() or "rows"
        config["resource_code"]      = body.get("resource_code") or None
        if body.get("service_response") is not None:
            config["service_response"] = body["service_response"]

        # Pre-flight: check for (method, url_path) collision with a different endpoint
        conflict = await db.fetchval(
            "SELECT id FROM api_gateway.endpoints WHERE method=$1 AND url_path=$2 AND id != $3",
            method, url_path, int(eid),
        )
        if conflict:
            return err(f"Another endpoint (id={conflict}) already uses {method} {url_path}")

        row = await db.fetchrow(
            """UPDATE api_gateway.endpoints SET
               name=$2, url_path=$3, method=$4,
               db_schema=$5, db_object=$6, db_type=$7,
               headers=$8::jsonb, body_schema=$9::jsonb,
               filters=$10::jsonb, columns=$11::jsonb,
               description=$12, status=$13, operation_type=$14,
               config=$15::jsonb, modified_at=NOW()
               WHERE id=$1 RETURNING *""",
            int(eid),
            name, url_path, method,
            db_schema, db_object, db_type,
            json.dumps(body.get("headers")     or []),
            json.dumps(body.get("body_schema") or {}),
            json.dumps(body.get("filters")     or []),
            json.dumps(body.get("columns")     or []),
            body.get("description") or None,
            body.get("status") or "draft",
            op_type,
            json.dumps(config),
        )
        if not row:
            return err("Not found")
        if db_type != "service":
            await _auto_register(db, db_schema, db_object, url_path)
        return ok(_row(row))
    except Exception as exc:
        logger.error("update_endpoint %s: %s", eid, exc)
        return err(str(exc))


# ---------------------------------------------------------------------------
# Delete / Status
# ---------------------------------------------------------------------------

@router.post("/delete")
async def delete_endpoint(
    body:  dict = Body(default={}),
    db:    asyncpg.Connection = Depends(get_db),
    admin: dict = Depends(get_current_admin),
):
    eid = body.get("id")
    if not eid:
        return err("id required")
    try:
        await db.execute(
            "DELETE FROM api_gateway.endpoints WHERE id=$1", int(eid)
        )
        return ok({"deleted": True})
    except Exception as exc:
        logger.error("delete_endpoint %s: %s", eid, exc)
        return err(str(exc))


@router.post("/set-status")
async def set_status(
    body:  dict = Body(default={}),
    db:    asyncpg.Connection = Depends(get_db),
    admin: dict = Depends(get_current_admin),
):
    eid    = body.get("id")
    status = body.get("status")
    if not eid:
        return err("id required")
    if status not in VALID_STATUSES:
        return err(f"status must be one of {sorted(VALID_STATUSES)}")
    try:
        row = await db.fetchrow(
            "UPDATE api_gateway.endpoints SET status=$2, modified_at=NOW() "
            "WHERE id=$1 RETURNING *",
            int(eid), status,
        )
        return ok(_row(row)) if row else err("Not found")
    except Exception as exc:
        logger.error("set_status %s→%s: %s", eid, status, exc)
        return err(str(exc))


# ---------------------------------------------------------------------------
# Schema setup — create translations table in a business schema
# ---------------------------------------------------------------------------

@router.post("/schema/setup-translations")
async def setup_schema_translations(
    body:  dict = Body(default={}),
    db:    asyncpg.Connection = Depends(get_db),
    admin: dict = Depends(get_current_admin),
):
    """
    Create the standard `translations` table in the given schema (idempotent).

    Body: { "schema": "company" }

    Run this once per business schema before using multilingual endpoint fields
    that write to that schema.
    """
    schema = (body.get("schema") or "").strip()
    if not schema:
        return err("schema is required")
    try:
        await create_schema_translations(db, schema)
        return ok({"schema": schema, "table": "translations", "created": True})
    except Exception as exc:
        logger.error("setup_schema_translations %s: %s", schema, exc)
        return err(str(exc))
